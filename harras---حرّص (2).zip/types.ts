export type PageView = 'dashboard' | 'fingerprint' | 'blockchain' | 'ai-analysis' | 'contact' | 'settings';

export interface LogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  resource: string;
  riskScore: number;
  hash: string;
  status: 'safe' | 'warning' | 'critical';
}

export interface StatCardProps {
  title: string;
  value: string;
  trend?: string;
  icon: React.ReactNode;
  color: 'green' | 'red' | 'yellow' | 'blue';
}

export interface NavItemProps {
  id: PageView;
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: (id: PageView) => void;
}