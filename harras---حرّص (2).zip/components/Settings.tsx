import React, { useState } from 'react';
import { Settings as SettingsIcon, Globe, Shield, Save } from 'lucide-react';

const Settings: React.FC = () => {
  const [domain, setDomain] = useState('www.harras.vercel.app');
  const [ipAddress, setIpAddress] = useState('192.168.1.105');

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <SettingsIcon className="text-green-600" size={32} />
          <span>إعدادات النظام</span>
        </h2>
        <p className="text-gray-500 mt-2">
          تهيئة نطاق النظام، إعدادات الشبكة، وبروتوكولات الحماية.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Domain Configuration */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
            <Globe className="text-green-500" size={20} />
            إعدادات النطاق (Domain)
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">النطاق الرسمي للنظام</label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-green-500 font-mono text-sm text-gray-600 ltr-text"
                  dir="ltr"
                />
                <div className="px-4 py-2 bg-green-50 text-green-600 rounded-xl text-sm font-bold flex items-center">
                    نشط
                </div>
              </div>
              <p className="text-xs text-gray-400 mt-2">
                يستخدم هذا النطاق للوصول الآمن من قبل الجهات الحكومية المصرحة.
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">عنوان الخادم (Server IP)</label>
              <div className="flex gap-2">
                 <input 
                  type="text" 
                  value={ipAddress}
                  onChange={(e) => setIpAddress(e.target.value)}
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 focus:outline-none focus:border-green-500 font-mono text-sm text-gray-600 ltr-text"
                  dir="ltr"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Security Level */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-sm">
           <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2 pb-4 border-b border-gray-100">
            <Shield className="text-green-500" size={20} />
            بروتوكولات الحماية
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                <div>
                    <p className="font-bold text-gray-800">تشفير البلوكتشين</p>
                    <p className="text-xs text-gray-500">تسجيل كل الحركات في السجل الموزع</p>
                </div>
                <div className="w-12 h-6 bg-green-500 rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                <div>
                    <p className="font-bold text-gray-800">المحلل الذكي (AI)</p>
                    <p className="text-xs text-gray-500">تفعيل التحليل الاستباقي للتهديدات</p>
                </div>
                <div className="w-12 h-6 bg-green-500 rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-100">
                <div>
                    <p className="font-bold text-gray-800">إشعارات الطوارئ</p>
                    <p className="text-xs text-gray-500">إرسال تنبيهات SMS للمشرفين</p>
                </div>
                 <div className="w-12 h-6 bg-gray-300 rounded-full relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm"></div>
                </div>
            </div>
          </div>
        </div>

        {/* System Info */}
        <div className="lg:col-span-2 bg-green-900 text-white p-6 rounded-2xl relative overflow-hidden flex justify-between items-center">
             <div className="relative z-10">
                 <h3 className="font-bold text-lg mb-1">نسخة النظام: v1.0.4-MVP</h3>
                 <p className="text-green-200 text-sm">آخر تحديث: 25 أكتوبر 2023</p>
             </div>
             <button className="relative z-10 bg-white text-green-900 px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-green-50 transition-colors">
                <Save size={18} />
                حفظ الإعدادات
             </button>

             {/* Background Decoration */}
             <div className="absolute top-0 left-0 w-full h-full opacity-10" style={{
                backgroundImage: 'linear-gradient(45deg, #22c55e 25%, transparent 25%, transparent 50%, #22c55e 50%, #22c55e 75%, transparent 75%, transparent)',
                backgroundSize: '20px 20px'
             }}></div>
        </div>

      </div>
    </div>
  );
};

export default Settings;