import React from 'react';
import { LayoutDashboard, Fingerprint, ShieldAlert, BrainCircuit, Phone, Settings } from 'lucide-react';
import { PageView } from '../types';
import { APP_NAME, TAGLINE } from '../constants';

interface SidebarProps {
  activePage: PageView;
  setActivePage: (page: PageView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage }) => {
  const navItems = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard size={20} /> },
    { id: 'fingerprint', label: 'بصمة البيانات', icon: <Fingerprint size={20} /> },
    { id: 'blockchain', label: 'سجلات البلوكتشين', icon: <ShieldAlert size={20} /> },
    { id: 'ai-analysis', label: 'المحلل الذكي', icon: <BrainCircuit size={20} /> },
    { id: 'settings', label: 'إعدادات النظام', icon: <Settings size={20} /> },
    { id: 'contact', label: 'الدعم الفني', icon: <Phone size={20} /> },
  ] as const;

  return (
    <aside className="w-64 bg-white h-screen fixed right-0 top-0 border-l border-green-100 flex flex-col shadow-[0_0_15px_rgba(0,0,0,0.05)] z-50">
      {/* Logo Section */}
      <div className="p-8 border-b border-green-50 flex flex-col items-center justify-center text-center">
        <div className="mb-4 text-green-700 animate-fade-in">
            {/* Saudi Emblem: Two Swords and a Palm Tree */}
            <svg viewBox="0 0 200 150" className="w-24 h-24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M100 15C100 15 80 45 60 50C80 50 95 35 100 25C105 35 120 50 140 50C120 45 100 15 100 15Z" />
                <path d="M97 50H103V85H97V50Z" />
                <path d="M40 105C60 100 130 75 160 65L165 70C135 80 65 105 45 110L40 105Z" />
                <path d="M160 105C140 100 70 75 40 65L35 70C65 80 135 105 155 110L160 105Z" />
                <path d="M35 107L45 113" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                <path d="M165 107L155 113" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
            </svg>
        </div>
        <h1 className="text-2xl font-black text-green-800 tracking-wide">{APP_NAME}</h1>
        <p className="text-xs font-bold text-green-600 mt-1 tracking-wider opacity-80">{TAGLINE}</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-6 px-3 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActivePage(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-200 group
              ${activePage === item.id 
                ? 'bg-green-50 text-green-700 shadow-sm border border-green-100' 
                : 'text-gray-500 hover:bg-gray-50 hover:text-green-600'
              }`}
          >
            <span className={`${activePage === item.id ? 'text-green-600' : 'text-gray-400 group-hover:text-green-500'}`}>
              {item.icon}
            </span>
            {item.label}
            {activePage === item.id && (
                <span className="mr-auto w-1.5 h-1.5 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
            )}
          </button>
        ))}
      </nav>
      
      {/* User Profile Snippet */}
      <div className="p-4 border-t border-green-50 bg-green-50/30">
        <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-100 border border-green-200 flex items-center justify-center text-green-700 font-bold">
                A
            </div>
            <div>
                <p className="text-sm font-bold text-gray-800">المسؤول الأمني</p>
                <p className="text-xs text-green-600">نشط الآن</p>
            </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;