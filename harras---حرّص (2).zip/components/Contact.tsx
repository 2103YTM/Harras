import React from 'react';
import { Phone, Mail, MapPin, Send } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-gray-800">التواصل والدعم الفني</h2>
        <p className="text-gray-500 mt-2">نحن هنا لدعمك على مدار الساعة لحماية بيانات منظمتك.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-2xl border border-green-100 shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-6 border-b pb-4">معلومات الاتصال المباشر</h3>
            
            <div className="space-y-6">
                <div className="flex items-center gap-4 group">
                    <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all">
                        <Phone size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">رقم الهاتف</p>
                        <p className="text-lg font-bold text-gray-800 dir-ltr">{CONTACT_INFO.phone}</p>
                    </div>
                </div>

                <div className="flex items-center gap-4 group">
                    <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all">
                        <Mail size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">البريد الإلكتروني</p>
                        <p className="text-lg font-bold text-gray-800">{CONTACT_INFO.email}</p>
                    </div>
                </div>

                <div className="flex items-center gap-4 group">
                    <div className="w-12 h-12 bg-green-50 rounded-full flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all">
                        <MapPin size={24} />
                    </div>
                    <div>
                        <p className="text-sm text-gray-500">المقر الرئيسي</p>
                        <p className="text-lg font-bold text-gray-800">الرياض، المملكة العربية السعودية</p>
                    </div>
                </div>
            </div>
        </div>

        <div className="bg-green-900 rounded-2xl p-8 text-white relative overflow-hidden">
             {/* Decorative Background Elements */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-green-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 transform translate-x-1/2 -translate-y-1/2"></div>
             <div className="absolute bottom-0 left-0 w-64 h-64 bg-green-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 transform -translate-x-1/2 translate-y-1/2"></div>

             <h3 className="text-xl font-bold mb-6 relative z-10">إرسال طلب دعم عاجل</h3>
             <form className="space-y-4 relative z-10">
                <div>
                    <label className="block text-sm text-green-200 mb-1">الاسم الكامل</label>
                    <input type="text" className="w-full bg-green-800/50 border border-green-700 rounded-lg px-4 py-2 focus:outline-none focus:border-green-400 text-white placeholder-green-500/50" placeholder="اسم الموظف المسؤول" />
                </div>
                <div>
                    <label className="block text-sm text-green-200 mb-1">نوع البلاغ</label>
                    <select className="w-full bg-green-800/50 border border-green-700 rounded-lg px-4 py-2 focus:outline-none focus:border-green-400 text-white">
                        <option>اشتباه بتسرب بيانات</option>
                        <option>مشكلة تقنية في النظام</option>
                        <option>طلب تقرير تدقيق</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm text-green-200 mb-1">التفاصيل</label>
                    <textarea className="w-full bg-green-800/50 border border-green-700 rounded-lg px-4 py-2 focus:outline-none focus:border-green-400 text-white placeholder-green-500/50 h-24" placeholder="اشرح المشكلة باختصار..."></textarea>
                </div>
                <button type="button" className="w-full bg-white text-green-900 font-bold py-3 rounded-lg hover:bg-green-100 transition-colors flex items-center justify-center gap-2">
                    <Send size={18} />
                    إرسال الطلب
                </button>
             </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;