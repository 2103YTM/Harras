import React, { useState } from 'react';
import { BrainCircuit, Cpu, ShieldCheck, AlertOctagon, Terminal } from 'lucide-react';
import { analyzeSecurityLog } from '../services/geminiService';

const AIAnalysis: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    setIsLoading(true);
    setAnalysisResult(null);
    
    // Simulate thinking time for effect + API call
    const result = await analyzeSecurityLog(inputText);
    setAnalysisResult(result);
    setIsLoading(false);
  };

  const loadScenario = () => {
    setInputText("قام المستخدم (Admin_02) بمحاولة تحميل ملف بحجم 4GB بعنوان 'قاعدة_بيانات_الكاملة.sql' إلى خادم خارجي غير مصرح به الساعة 3:00 فجراً.");
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <BrainCircuit className="text-green-600" size={32} />
          <span>المحلل الأمني الذكي</span>
        </h2>
        <p className="text-gray-500 mt-2 max-w-2xl">
          يستخدم النظام تقنيات الذكاء الاصطناعي التوليدي لتحليل الأنماط السلوكية المعقدة والتنبؤ بمحاولات تسريب البيانات قبل اكتمالها.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-lg shadow-green-100/50">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-800 flex items-center gap-2">
              <Terminal size={18} className="text-gray-400" />
              أدخل بيانات السجل للتحليل
            </h3>
            <button 
              onClick={loadScenario} 
              className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-600 px-3 py-1 rounded-full transition-colors"
            >
              تحميل سيناريو تجريبي
            </button>
          </div>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="الصق نص السجل أو وصف الحدث هنا..."
            className="w-full h-40 p-4 rounded-xl border border-gray-200 bg-gray-50 focus:bg-white focus:border-green-500 focus:ring-2 focus:ring-green-200 outline-none transition-all resize-none font-mono text-sm"
          ></textarea>
          <div className="mt-4 flex justify-end">
            <button
              onClick={handleAnalyze}
              disabled={isLoading || !inputText}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-white font-bold shadow-lg transition-all ${
                isLoading 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-green-600 hover:bg-green-700 hover:shadow-green-500/30 active:transform active:scale-95'
              }`}
            >
              {isLoading ? (
                <>
                  <Cpu className="animate-spin" size={20} />
                  جاري التحليل...
                </>
              ) : (
                <>
                  <BrainCircuit size={20} />
                  تحليل التهديد
                </>
              )}
            </button>
          </div>
        </div>

        {/* Output Section */}
        <div className={`rounded-2xl border transition-all duration-500 flex flex-col ${analysisResult ? 'bg-white border-green-200 shadow-xl' : 'bg-gray-50 border-dashed border-gray-300 items-center justify-center text-gray-400'}`}>
          {analysisResult ? (
            <div className="p-6 h-full flex flex-col">
              <div className="flex items-center gap-2 mb-4 pb-4 border-b border-gray-100">
                <ShieldCheck className="text-green-600" size={24} />
                <h3 className="font-bold text-gray-800">نتيجة التحليل</h3>
              </div>
              <div className="prose prose-sm max-w-none text-gray-700 leading-relaxed whitespace-pre-line flex-1 overflow-y-auto">
                {analysisResult}
              </div>
              <div className="mt-6 p-3 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3">
                <AlertOctagon className="text-red-500" size={20} />
                <span className="text-xs text-red-700 font-bold">تم تسجيل هذا التحليل في البلوكتشين لغرض التدقيق (Hash: 0x92f...a12)</span>
              </div>
            </div>
          ) : (
             <div className="text-center p-12">
               <Cpu size={48} className="mx-auto mb-4 opacity-20" />
               <p>بانتظار المدخلات لبدء المعالجة...</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAnalysis;