import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, Lock, AlertTriangle, Database } from 'lucide-react';
import { CHART_DATA, MOCK_LOGS } from '../constants';
import { PageView } from '../types';

interface DashboardProps {
  onNavigate: (page: PageView) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-800">لوحة القيادة المركزية</h2>
          <p className="text-gray-500 mt-1">نظرة عامة على حالة النظام وتدفق البيانات</p>
        </div>
        <div className="flex gap-2">
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-bold border border-green-200 animate-pulse">
                النظام نشط
            </span>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div 
            onClick={() => onNavigate('fingerprint')}
            className="bg-white p-6 rounded-2xl border border-green-100 shadow-sm hover:shadow-green-200 hover:border-green-300 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">تدفق البيانات (ساعة)</p>
              <h3 className="text-3xl font-bold text-gray-800 group-hover:text-green-600 transition-colors">2.4TB</h3>
            </div>
            <div className="p-3 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-100">
              <Activity size={24} />
            </div>
          </div>
          <p className="text-xs text-green-600 mt-4 flex items-center gap-1">
             +12% زيادة عن المعدل الطبيعي
          </p>
        </div>

        <div 
             onClick={() => onNavigate('blockchain')}
             className="bg-white p-6 rounded-2xl border border-green-100 shadow-sm hover:shadow-green-200 hover:border-green-300 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">الكتل المؤمنة</p>
              <h3 className="text-3xl font-bold text-gray-800 group-hover:text-green-600 transition-colors">843k</h3>
            </div>
            <div className="p-3 bg-green-50 text-green-600 rounded-lg group-hover:bg-green-100">
              <Lock size={24} />
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-4">آخر مزامنة: قبل 2 ثانية</p>
        </div>

        <div 
             onClick={() => onNavigate('dashboard')}
             className="bg-white p-6 rounded-2xl border-l-4 border-l-red-500 shadow-sm hover:shadow-red-100 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">تنبيهات حرجة</p>
              <h3 className="text-3xl font-bold text-red-600">3</h3>
            </div>
            <div className="p-3 bg-red-50 text-red-600 rounded-lg group-hover:bg-red-100">
              <AlertTriangle size={24} />
            </div>
          </div>
          <p className="text-xs text-red-500 mt-4 font-bold">يتطلب تدخل فوري</p>
        </div>

        <div 
            onClick={() => onNavigate('ai-analysis')}
            className="bg-white p-6 rounded-2xl border border-green-100 shadow-sm hover:shadow-purple-200 hover:border-purple-300 transition-all cursor-pointer group"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">دقة التنبؤ (AI)</p>
              <h3 className="text-3xl font-bold text-gray-800 group-hover:text-purple-600 transition-colors">98.2%</h3>
            </div>
            <div className="p-3 bg-purple-50 text-purple-600 rounded-lg group-hover:bg-purple-100">
              <Database size={24} />
            </div>
          </div>
          <p className="text-xs text-green-600 mt-4">النموذج يعمل بكفاءة</p>
        </div>
      </div>

      {/* Chart Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-green-100 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-6 flex items-center gap-2">
            <span className="w-2 h-6 bg-green-500 rounded-full"></span>
            تحليل تدفق البيانات مقابل التهديدات
          </h3>
          <div className="h-[300px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={CHART_DATA}>
                <defs>
                  <linearGradient id="colorFlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorThreat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }}
                />
                <Area type="monotone" dataKey="flow" stroke="#22c55e" strokeWidth={3} fillOpacity={1} fill="url(#colorFlow)" name="تدفق البيانات" />
                <Area type="monotone" dataKey="threat" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorThreat)" name="مؤشر الخطر" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Logs */}
        <div className="bg-white p-6 rounded-2xl border border-green-100 shadow-sm overflow-hidden">
          <h3 className="text-lg font-bold text-gray-800 mb-6">سجل النشاط الحي</h3>
          <div className="space-y-4">
            {MOCK_LOGS.map((log) => (
              <div key={log.id} className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 border border-gray-100 hover:border-green-300 transition-colors">
                <div className={`w-2 h-2 rounded-full ${log.status === 'critical' ? 'bg-red-500 animate-pulse' : log.status === 'warning' ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
                <div className="flex-1">
                  <p className="text-sm font-bold text-gray-700">{log.action}</p>
                  <p className="text-xs text-gray-400">{log.user} | {log.timestamp.split(' ')[1]}</p>
                </div>
                <div className="text-xs font-mono text-gray-400 bg-white px-2 py-1 rounded border">
                  {log.hash.substring(0, 6)}...
                </div>
              </div>
            ))}
          </div>
          <button 
            onClick={() => onNavigate('blockchain')}
            className="w-full mt-4 py-2 text-sm text-green-700 font-bold border border-green-200 rounded-lg hover:bg-green-50 transition-colors"
          >
            عرض السجل الكامل
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;