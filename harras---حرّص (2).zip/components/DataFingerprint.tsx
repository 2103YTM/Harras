import React from 'react';
import { Fingerprint, User, Globe, Server } from 'lucide-react';

const DataFingerprint: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <Fingerprint className="text-green-600" size={32} />
          <span>بصمة تدفق البيانات</span>
        </h2>
        <p className="text-gray-500 mt-2">
          مراقبة حية لسلوك الموظفين والواجهات لإنشاء نمط مرجعي واكتشاف الشذوذ.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* User Behavior Card */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-400 to-transparent"></div>
            <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg">سلوك المستخدمين</h3>
                <User className="text-green-500 opacity-50" />
            </div>
            
            <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">نشاط خارج الدوام</span>
                    <span className="text-green-600 font-bold bg-green-50 px-2 py-1 rounded">0.4%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '0.4%' }}></div>
                </div>

                <div className="flex items-center justify-between text-sm pt-2">
                    <span className="text-gray-600">معدل نقل الملفات</span>
                    <span className="text-yellow-600 font-bold bg-yellow-50 px-2 py-1 rounded">مرتفع</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className="bg-yellow-400 h-2 rounded-full" style={{ width: '70%' }}></div>
                </div>
            </div>
        </div>

        {/* Network Traffic Card */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-transparent"></div>
            <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg">الواجهات والشبكة</h3>
                <Globe className="text-blue-500 opacity-50" />
            </div>
             <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">طلبات API غير معروفة</span>
                    <span className="text-red-600 font-bold bg-red-50 px-2 py-1 rounded">3 محاولات</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                    <div className="bg-red-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                </div>
            </div>
            <div className="mt-6 p-4 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                <p className="text-xs text-center text-gray-500">جاري تحليل 14 نقطة اتصال...</p>
            </div>
        </div>

        {/* System Health Card */}
        <div className="bg-white p-6 rounded-2xl border border-green-200 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-400 to-transparent"></div>
            <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold text-lg">سلامة الخوادم</h3>
                <Server className="text-purple-500 opacity-50" />
            </div>
            <div className="flex items-center justify-center h-32">
                 <div className="relative w-24 h-24 flex items-center justify-center">
                    <div className="absolute inset-0 border-4 border-gray-100 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-green-500 rounded-full border-t-transparent animate-spin"></div>
                    <span className="text-xl font-bold text-gray-700">99%</span>
                 </div>
            </div>
            <p className="text-center text-sm text-green-600 font-medium">الوضع مستقر</p>
        </div>
      </div>

       {/* Visual Representation of Fingerprint */}
       <div className="bg-gray-900 rounded-2xl p-8 relative overflow-hidden text-white min-h-[300px] flex items-center justify-center">
            {/* Cyberpunk Grid Background */}
            <div className="absolute inset-0 opacity-20" style={{
                backgroundImage: 'linear-gradient(rgba(0, 255, 136, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 136, 0.1) 1px, transparent 1px)',
                backgroundSize: '20px 20px'
            }}></div>
            
            <div className="relative z-10 text-center">
                <div className="inline-block p-4 border-2 border-green-500 rounded-full mb-4 shadow-[0_0_20px_rgba(34,197,94,0.6)] animate-pulse">
                    <Fingerprint size={64} className="text-green-400" />
                </div>
                <h3 className="text-2xl font-bold text-green-400 tracking-widest mb-2">بصمة النظام نشطة</h3>
                <p className="text-gray-400 text-sm max-w-md mx-auto">
                    يتم مقارنة 4,200 نقطة بيانات في الثانية مع النماذج التاريخية لضمان عدم وجود انحراف سلوكي.
                </p>
            </div>
       </div>
    </div>
  );
};

export default DataFingerprint;