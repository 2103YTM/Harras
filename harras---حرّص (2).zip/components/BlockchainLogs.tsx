import React from 'react';
import { MOCK_LOGS } from '../constants';
import { Shield, Link } from 'lucide-react';

const BlockchainLogs: React.FC = () => {
  return (
    <div className="space-y-8 animate-fade-in">
      <header>
        <h2 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
          <Link className="text-green-600" size={32} />
          <span>سجل البلوكتشين الغير قابل للتعديل</span>
        </h2>
        <p className="text-gray-500 mt-2">
          يضمن هذا السجل نزاهة البيانات حيث يتم تشفير كل عملية وحفظها كسلسلة كتل مترابطة.
        </p>
      </header>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">الحالة</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">توقيت الكتلة</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">المعرف (Hash)</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">الحدث</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">المستخدم</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">التحقق</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {MOCK_LOGS.map((log) => (
                <tr key={log.id} className="hover:bg-green-50/30 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${log.status === 'critical' ? 'bg-red-100 text-red-800' :
                        log.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'}`}>
                      {log.status === 'critical' ? 'خطر عالي' : log.status === 'warning' ? 'تحذير' : 'آمن'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">
                    {log.timestamp}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono bg-gray-50 rounded select-all">
                    {log.hash}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800 font-bold">
                    {log.action}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs">👤</div>
                        {log.user}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                    <div className="flex items-center gap-1">
                        <Shield size={14} />
                        <span>مؤكد 100%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-gray-50 border-t border-gray-200 text-center">
            <button className="text-green-700 text-sm font-bold hover:underline">تحميل السجل الكامل (CSV)</button>
        </div>
      </div>
    </div>
  );
};

export default BlockchainLogs;