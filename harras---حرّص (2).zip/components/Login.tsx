import React, { useState } from 'react';
import { ShieldCheck, Lock, ScanLine, ArrowLeft } from 'lucide-react';
import { APP_NAME, TAGLINE } from '../constants';

interface LoginProps {
  onLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    
    setLoading(true);
    // Simulate biometric scan delay
    setTimeout(() => {
      onLogin();
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="cyber-grid absolute inset-0 opacity-10 pointer-events-none"></div>
      
      <div className="w-full max-w-md bg-white p-8 rounded-3xl shadow-2xl border border-green-100 relative z-10 animate-fade-in-up">
        <div className="text-center mb-8">
            <div className="flex justify-center mb-4 text-green-700">
               <svg viewBox="0 0 200 150" className="w-20 h-20" fill="currentColor">
                    <path d="M100 15C100 15 80 45 60 50C80 50 95 35 100 25C105 35 120 50 140 50C120 45 100 15 100 15Z" />
                    <path d="M97 50H103V85H97V50Z" />
                    <path d="M40 105C60 100 130 75 160 65L165 70C135 80 65 105 45 110L40 105Z" />
                    <path d="M160 105C140 100 70 75 40 65L35 70C65 80 135 105 155 110L160 105Z" />
                    <path d="M35 107L45 113" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                    <path d="M165 107L155 113" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
               </svg>
            </div>
            <h1 className="text-3xl font-black text-gray-800 mb-1">{APP_NAME}</h1>
            <p className="text-sm font-bold text-green-600 tracking-wide">{TAGLINE}</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">معرف المستخدم</label>
            <div className="relative">
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pl-10 focus:outline-none focus:border-green-500 transition-colors text-right"
                  placeholder="رقم الهوية / المعرف"
                />
                <ShieldCheck className="absolute left-3 top-3.5 text-gray-400" size={18} />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">كلمة المرور</label>
            <div className="relative">
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pl-10 focus:outline-none focus:border-green-500 transition-colors text-right"
                  placeholder="••••••••"
                />
                <Lock className="absolute left-3 top-3.5 text-gray-400" size={18} />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={loading || !username || !password}
            className={`w-full bg-green-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-green-700/20 hover:bg-green-800 transition-all flex items-center justify-center gap-2 relative overflow-hidden ${loading ? 'cursor-not-allowed opacity-90' : 'hover:-translate-y-1'}`}
          >
            {loading ? (
                <div className="flex items-center gap-2 animate-pulse">
                    <ScanLine className="animate-spin-slow" />
                    جاري التحقق من البصمة...
                </div>
            ) : (
                <>
                    تسجيل الدخول الآمن
                    <ArrowLeft size={20} />
                </>
            )}
            {/* Scan Effect */}
            {loading && (
                <div className="absolute top-0 left-0 w-full h-1 bg-green-400 animate-scan"></div>
            )}
          </button>
        </form>

        <div className="mt-8 text-center">
            <p className="text-xs text-gray-400 flex items-center justify-center gap-1">
                <Lock size={12} />
                هذا النظام محمي بواسطة تشفير البلوكتشين
            </p>
        </div>
      </div>
    </div>
  );
};

export default Login;