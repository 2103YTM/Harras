import React, { useState } from 'react';
import { X, Copy, Check, Share2, MessageCircle } from 'lucide-react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  
  if (!isOpen) return null;

  // Use the ACTUAL window location, not the fake one
  const shareUrl = window.location.href;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsapp = () => {
    const text = `اطلع على نظام "حرّص" الجديد لحماية البيانات الحكومية:\n${shareUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm relative z-10 animate-scale-up border border-green-100 p-6">
        <button 
            onClick={onClose}
            className="absolute left-4 top-4 text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded-full transition-colors"
        >
            <X size={20} />
        </button>

        <div className="text-center mb-6">
            <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Share2 size={24} />
            </div>
            <h3 className="text-xl font-bold text-gray-800">مشاركة النظام</h3>
            <p className="text-sm text-gray-500 mt-1">شارك رابط المعاينة المباشر مع فريقك</p>
        </div>

        {/* QR Code Placeholder using API */}
        <div className="bg-white p-4 rounded-xl border-2 border-dashed border-gray-200 mb-6 flex justify-center">
            <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(shareUrl)}&color=166534`} 
                alt="QR Code" 
                className="w-32 h-32 opacity-90"
            />
        </div>

        <div className="space-y-3">
            <button 
                onClick={handleCopy}
                className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl hover:border-green-400 hover:bg-white transition-all group"
            >
                <span className="text-sm font-bold text-gray-700 truncate max-w-[200px] dir-ltr font-mono">{shareUrl}</span>
                <span className={`text-sm font-bold ${copied ? 'text-green-600' : 'text-gray-400 group-hover:text-green-600'}`}>
                    {copied ? <Check size={18} /> : <Copy size={18} />}
                </span>
            </button>

            <button 
                onClick={handleWhatsapp}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#25D366] text-white rounded-xl font-bold hover:bg-[#20bd5a] transition-colors shadow-lg shadow-green-500/20"
            >
                <MessageCircle size={20} />
                مشاركة عبر واتساب
            </button>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;