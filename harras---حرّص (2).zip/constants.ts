import { LogEntry } from './types';

export const APP_NAME = "حرّص";
export const TAGLINE = "حرّص ولا تخون";

export const CONTACT_INFO = {
  phone: "+966511035698",
  email: "YasserTalMalki@gmail.com"
};

export const MOCK_LOGS: LogEntry[] = [
  {
    id: "LOG-9921",
    timestamp: "2023-10-25 14:30:05",
    user: "موظف 102",
    action: "تصدير بيانات ضخمة",
    resource: "قاعدة بيانات المواطنين",
    riskScore: 85,
    hash: "0x8f2a...9d12",
    status: 'critical'
  },
  {
    id: "LOG-9922",
    timestamp: "2023-10-25 14:32:10",
    user: "موظف 055",
    action: "دخول للنظام",
    resource: "بوابة الموارد البشرية",
    riskScore: 12,
    hash: "0x3b1c...4a21",
    status: 'safe'
  },
  {
    id: "LOG-9923",
    timestamp: "2023-10-25 14:45:00",
    user: "مدير النظام",
    action: "تعديل صلاحيات",
    resource: "لوحة التحكم",
    riskScore: 45,
    hash: "0x7e9d...1b55",
    status: 'warning'
  },
  {
    id: "LOG-9924",
    timestamp: "2023-10-25 15:01:22",
    user: "موظف 102",
    action: "محاولة دخول متكررة",
    resource: "الأرشيف السري",
    riskScore: 92,
    hash: "0x1a2b...3c4d",
    status: 'critical'
  }
];

export const CHART_DATA = [
  { name: '08:00', flow: 400, threat: 24 },
  { name: '10:00', flow: 300, threat: 13 },
  { name: '12:00', flow: 600, threat: 85 },
  { name: '14:00', flow: 200, threat: 10 },
  { name: '16:00', flow: 500, threat: 45 },
  { name: '18:00', flow: 100, threat: 5 },
];