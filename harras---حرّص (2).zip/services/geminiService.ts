import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeSecurityLog = async (logDetails: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      أنت خبير أمن سيبراني في نظام "حرّص" الحكومي.
      قم بتحليل سجل النظام التالي وتحديد ما إذا كان يشير إلى تسرب بيانات محتمل.
      
      السجل: "${logDetails}"
      
      المطلوب:
      1. تقييم مستوى الخطورة (منخفض، متوسط، عالي).
      2. شرح السبب بناءً على أنماط السلوك (بصمة تدفق البيانات).
      3. التوصية بالإجراء الفوري.
      
      أجب باللغة العربية وبأسلوب تقني مهني ومختصر.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "تعذر تحليل البيانات في الوقت الحالي.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "حدث خطأ أثناء الاتصال بنظام الذكاء الاصطناعي. يرجى التحقق من الشبكة.";
  }
};